package com.example.moolah_master_join_league

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
