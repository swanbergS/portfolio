import logging
import azure.functions as func
from shared_code.DataManager import FantasyStockDataStore


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueID = int(req_body.get("leagueID"))
        week_number = int(req_body.get('week_number'))

        myDB = FantasyStockDataStore()
        matchups = myDB.GetWeekMatchups(leagueID, week_number)
        for matchup in matchups:
            matchup['week_status'] = 'closed'
        myDB.UpdateWeekMatchups(matchups)

        return func.HttpResponse("Success", status_code=200)
    except Exception as e:
        return func.HttpResponse(
             f"UNEXPECTED ERROR - {e}", status_code=400)