import logging
import json
from azure.cosmos import CosmosClient
import azure.functions as func
from shared_code.LeagueHelper import LeagueHelper
from shared_code.DataManager import FantasyStockDataStore
from datetime import date,datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP **CreateLeague** trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueName = req_body.get('league')
        owner = req_body.get('owner')
        capacity = int(req_body.get('capacity'))
        startdate = req_body.get('startdate')

        if startdate == None:
            return func.HttpResponse(f"ERROR - 'startdate' missing", status_code=400)

        start_date = datetime.strptime(startdate, "%Y-%m-%d").date()
        if start_date.isoweekday() != 1:
            return func.HttpResponse(f"ERROR - {startdate} is not a monday ", status_code=400)

        myDB = FantasyStockDataStore()
        leagueObj = LeagueHelper(leagueName, owner, capacity, startdate)
        league = leagueObj.createLeagueObject()
        new_league = myDB.CreateOrUpdateLeague(league)

        #create schedule
        matchups = leagueObj.get_schedule(new_league['id'])
        matchups = myDB.UpdateWeekMatchups(matchups)

        return func.HttpResponse(json.dumps(new_league, indent=True), status_code=201, headers={'Content-Type': 'application/json'})

    except Exception as e:
        return func.HttpResponse(f"UNEXPECTED ERROR - {e}", status_code=400)