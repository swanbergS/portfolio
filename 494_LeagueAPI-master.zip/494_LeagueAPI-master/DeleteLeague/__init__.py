import logging
import json
from azure.cosmos import CosmosClient
import azure.functions as func
from shared_code.LeagueHelper import LeagueHelper
from shared_code.DataManager import FantasyStockDataStore

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP **CreateLeague** trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueID = int(req_body.get('leagueID'))

        myDB = FantasyStockDataStore()
        myDB.DeleteLeague(leagueID)

        result = {
            'status': 'Succeeded'
        }
        return func.HttpResponse(json.dumps(result, indent=True), status_code=200, headers={'Content-Type': 'application/json'})

    except Exception as e:
        return func.HttpResponse(f"UNEXPECTED ERROR - {e}", status_code=400)