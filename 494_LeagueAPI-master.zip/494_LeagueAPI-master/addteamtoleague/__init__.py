import logging
import json
import azure.functions as func
from shared_code.DataManager import FantasyStockDataStore


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP **AddTeamToLeague** trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueID = int(req_body.get("leagueID"))
        teamName = req_body.get('team')
        owner = req_body.get('owner')

        myDB = FantasyStockDataStore()
        league = myDB.GetLeague(leagueID)
        if league == None:
            return func.HttpResponse(f"ERROR: '{leagueID}' NOT Found", status_code=400)

        for team in league.get('teams'):
            currentTeamName = team.get('team')
            if currentTeamName == '':
                team['team'] = teamName
                team['owner'] = owner

        league = myDB.CreateOrUpdateLeague(league)
        return func.HttpResponse(json.dumps(league, indent=True), status_code=200, headers={'Content-Type': 'application/json'})

    except Exception as e:
        return func.HttpResponse(f"UNEXPECTED ERROR - {e}", status_code=400)


