import logging
import json
from azure.cosmos import CosmosClient
import azure.functions as func
from shared_code.LeagueHelper import LeagueHelper
from shared_code.DataManager import FantasyStockDataStore
from shared_code.validatestockchanges import stockchangevalidator

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP **AddStockToLeague** trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueID = req_body.get('leagueID')
        team = req_body.get('teamID')
        week = req_body.get('week')
        day = req_body.get('day')
        stocks = req_body.get('stocks')

        stock_obj = stockchangevalidator(leagueID, team, stocks)
        result = stock_obj.buildvalidrequest()

        if result['status'] != 'valid':
            return func.HttpResponse(result['error_msg'], status_code=400)
           
        myDB = FantasyStockDataStore()
        team = myDB.AddStocksToTeam(leagueID,team,week,day,result['stock_obj'])
        
        return func.HttpResponse(json.dumps(team, indent=True), status_code=201, headers={'Content-Type': 'application/json'})

    except Exception as e:
        return func.HttpResponse(f"UNEXPECTED ERROR - {e}", status_code=400)