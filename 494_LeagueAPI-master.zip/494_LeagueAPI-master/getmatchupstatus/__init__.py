import logging
import json
import azure.functions as func
from shared_code.DataManager import FantasyStockDataStore
from shared_code.generatestats import TeamStats


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueID = int(req_body.get('leagueID'))
        week_number = int(req_body.get('week_number'))
        team = int(req_body.get('teamID'))

        myDB = FantasyStockDataStore()
        matchups = myDB.GetWeekMatchups(leagueID, week_number)
      
        #find the team in the weekly matchup
        for matchup in matchups:
            if matchup['team'] == team:
                my_team = matchup['team']
                match_id = matchup['matchup_id']

        if my_team == None:
            return func.HttpResponse(f"unknown team number '{team}'", status_code=400)

        #find opposing team
        for matchup in matchups:
            if matchup['matchup_id'] == match_id:
                opposing_team = matchup['team']  

        #get current stats
        my_team_obj = TeamStats(my_team,matchups)
        my_team_stats = my_team_obj.get_stats()

        opposing_team_obj = TeamStats(opposing_team,matchups)
        opposing_team_stats = opposing_team_obj.get_stats()

        my_matchup = {}
        my_matchup['team1'] = my_team_stats
        my_matchup['team2'] = opposing_team_stats

        return func.HttpResponse(json.dumps(my_matchup, indent=True), status_code=200, headers={'Content-Type': 'application/json'})

    except Exception as e:
        return func.HttpResponse(f"UNEXPECTED ERROR - {e}", status_code=400)

