import uuid
from azure.cosmos import CosmosClient

class FantasyStockDataStore:
    def __init__(self):
        self.mysettings = {
                'url' : 'https://csc494.documents.azure.com:443/',
                'key' : 'a52fEosQTZjIV83PoHoRsVItHQ2tyd5tnFPlV7JWvPjwHsnRZF5EbiddN2zL7BNUamlftlGcQes9jn6vaZ656w==',
                'database_name' : 'csc494',
                'leagues_container_name' : 'Leagues',
                'schedule_container_name': "Schedule"
                }
        self.client = CosmosClient(self.mysettings['url'], credential=self.mysettings['key'])
        self.database = self.client.get_database_client(self.mysettings['database_name'])
          

    def _queryContainer(self, container_name, data_query, cross_query=True):
        container = self.database.get_container_client(self.mysettings[container_name])
        items = list(container.query_items(query=data_query, enable_cross_partition_query=cross_query))
        
        return items

    def _createUpdateItem(self, container_name, item):
        container = self.database.get_container_client(self.mysettings[container_name])

        if item.get('id') == None:
            item['id'] = str(uuid.uuid1())
        newItem = container.upsert_item(item)
        return newItem

    def _deleteItem(self, container_name, item, partitionKey):
        container = self.database.get_container_client(self.mysettings[container_name])
        container.delete_item(item, partitionKey)


    def CreateOrUpdateLeague(self, league):

        #if no id then find new id
        if league.get('id') == None:
            data_query = f'SELECT r.id FROM Leagues r'
            items = self._queryContainer('leagues_container_name', data_query)
            max_id = 0
            if len(items) > 0:
                for item in items:
                    if int(item['id']) > max_id:
                        max_id = int(item['id'])
            max_id = max_id + 1
            league['id'] = str(max_id)

        return self._createUpdateItem('leagues_container_name', league)


    def DeleteLeague(self, leagueID):
        data_query = f'SELECT * FROM Schedule s WHERE s.leagueID="{leagueID}"'
        schedule_list = self._queryContainer('schedule_container_name', data_query)

        for schedule in schedule_list:
            self._deleteItem('schedule_container_name', schedule, schedule['leagueID'])

        data_query = f'SELECT * FROM Leagues l WHERE l.id="{leagueID}"'
        leagues = self._queryContainer('leagues_container_name', data_query)

        for league in leagues:
            self._deleteItem('leagues_container_name', league, league['id'])

        return



    def GetWeekMatchups(self, leagueID, week, day=None):
        data_query = f'SELECT * FROM Schedule r WHERE r.leagueID="{leagueID}" AND r.week_number="{week}"'
        if day != None:
            data_query = data_query + f' AND r.day_number="{day}"'
        items = self._queryContainer('schedule_container_name', data_query)
        return items

    def UpdateWeekMatchups(self, matchups):
        for matchup in matchups:
            self._createUpdateItem('schedule_container_name', matchup)

        return   

    def GetWeekLineup(self, leagueID, week, team):
        data_query = f'SELECT * FROM Schedule r WHERE r.leagueID="{leagueID}" AND r.week_number="{week}" AND r.team="{team}"'
        items = self._queryContainer('schedule_container_name', data_query)
        return items

    def GetLeague(self, leagueID):
        data_query = f'SELECT * FROM Leagues l WHERE l.id="{leagueID}"'
        items = self._queryContainer('leagues_container_name', data_query)

        if len(items) > 0:
            return items[0]

        return None


    def AddStocksToTeam(self, leagueID, team, week, day, stocks):
        id = f'{leagueID:0>3}-{week:0>2}-{day:0>2}-{team:0>2}'
        data_query = f'SELECT * FROM Schedule s WHERE s.id="{id}"'

        teams = self._queryContainer('schedule_container_name', data_query)
        if len(teams) > 0:
            team = teams[0]

        team['stocks'] = stocks
        return self._createUpdateItem('schedule_contianer_name', team)

        
        

    

         
