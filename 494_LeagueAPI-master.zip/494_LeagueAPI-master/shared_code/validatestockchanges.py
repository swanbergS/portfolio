class stockchangevalidator:
    def __init__(self, leagueid, team, stocks):
        self.leagueid = leagueid
        self.team = team
        self.stocks = stocks

    def buildvalidrequest(self):
        stocks = []
        max_shares = 1000
        max_shares_per_stock = 250
        share_count = 0


        if self.stocks == None:
            return {
                'status': 'error',
                'stock_obj': None,
                'error_msg':f"'stocks' field missing"
            }

        for stock in self.stocks:
            ticker = stock.get('ticker')
            quantity = stock.get('quantity')
            if ticker == None or quantity == None:
                 return {
                'status': 'error',
                'stock_obj': None,
                'error_msg':f"'ticker' or 'quantity' field is missing"
            }

            quantity = int(quantity)
            if quantity > max_shares_per_stock:
                   return {
                'status': 'error',
                'stock_obj': None,
                'error_msg':f"'{ticker}' quantity of {quantity} is over limit of {max_shares_per_stock}"
            }

            share_count = share_count + quantity

            if share_count > max_shares:
                  return {
                'status': 'error',
                'stock_obj': None,
                'error_msg':f"total quantity of shares exceeds the limit of {max_shares}"
            }

            valid_stock = {
                'ticker': f'{ticker}',
                'quantity': f'{quantity}'
            }
            stocks.append(valid_stock)
        
        return {
                'status': 'valid',
                'stock_obj': stocks,
                'error_msg':None
            }     
            



