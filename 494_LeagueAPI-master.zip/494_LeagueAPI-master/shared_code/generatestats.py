from decimal import Decimal

class StockStat:
    def __init__(self, ticker):
        self.ticker = ticker
        self.points = int(0)

       
class TeamStats:
    def __init__(self, team, matchups):
        self.team = team
        self.team_matchups = []
        for matchup in matchups:
            if matchup['team'] == team:
                self.team_matchups.append(matchup)

        self.stocks = []    

    def _getStock(self, ticker):
        for stock_stat in self.stocks:
            if stock_stat.ticker == ticker:
                return stock_stat
        
        stock_stat = StockStat(ticker)
        self.stocks.append( stock_stat)
        
        return stock_stat

    def get_stats(self):
        team_stat = {}
        team_stat['team'] = self.team
        team_stat['total_points'] = 0
        #for matchup in self.team_matchups:
        #    if matchup['day_status'] == 'closed':
        #        for stock in matchup['stocks']:
        #            stock_dif = Decimal(stock['close_price']) - Decimal(stock['open_price'])
        #            stock_percent = stock_dif / Decimal(stock['open_price'])
        #            stock_points = stock_percent * int(stock['quantity'])
        #
        #            mystock = self._getStock(stock['ticker'])
        #            mystock.points = mystock.point + stock_points
        
        #Add Dummy Stock info
        mystock1 = self._getStock('MSFT')
        mystock2 = self._getStock('AAPL')
         
        # generate stock stats
        total_points = 0
        team_stat['stocks'] = []
        for stock_stat in self.stocks:
            stock_obj = {}
            stock_obj['ticker'] = stock_stat.ticker
            stock_obj['points'] = stock_stat.points
            team_stat['stocks'].append(stock_obj)
            total_points = total_points + stock_stat.points
        
        team_stat['total_points'] = total_points
        return team_stat

