class MatchupBuilder:
    def __init__(self, leagueID, week_number, matchups):
        self.matchups = matchups
        self.leagueID = leagueID
        self.week_number = week_number


    def _lookupMatch(self, matchList, matchID):
        for match in matchList:
            if match['matchup_id'] == matchID:
                return match

        return None


    def BuildOuput(self):
        matchups = {}

        matchups['leagueID'] = f'{self.leagueID}'
        matchups['week_number'] = f'{self.week_number}'
        matchups['matches'] = []

        for matchup in self.matchups:
            match = self._lookupMatch(matchups['matches'], matchup['matchup_id'])
            if match == None:
                match = {}
                match['matchup_id'] = matchup['matchup_id']
                match['team1'] = matchup['team']
                matchups['matches'].append(match)
            else:
                match['team2'] = matchup['team']

        return matchups

            
