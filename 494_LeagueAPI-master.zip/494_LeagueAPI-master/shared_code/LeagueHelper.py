
class LeagueHelper:
    def __init__(self,name,owner,capacity,startdate):
        self.name = name
        self.owner = owner

       #making sure the league is always an even number of teams
        if int(capacity) % 2 == 1:
            self.capacity = int(capacity) + 1
        else:
            self.capacity = int(capacity)

        self.startdate = startdate

    #Got from this URL:https://itectec.com/software/python-scheduling-balanced-home-away-round-robin-tournament-algorithm/
    def round_robin(self, teams, rounds):
        # bye
        if len(teams) % 2:
            teams.append(None)

        schedule = []
        for turn in range(rounds):
            pairings = []
            for i in range(int(len(teams) / 2)):
                pairings.append((teams[i], teams[len(teams) - i - 1]))
            teams.insert(1, teams.pop())
            schedule.append(pairings)

        return schedule

    def get_schedule(self, leagueID):
        schedule_matchups = []
        
        #create list of team ids
        teams = []
        for y in range(self.capacity):
            teams.append(y+1)

        #use round-robin algorithm to create matchups
        schedule = self.round_robin(teams, (self.capacity-1))

        week_number = 1
        matchup_id = 0
        for week in schedule:
            for match in week:
                for i in range(5):
                    matchup_id = matchup_id + 1
                    day_number = i+1

                    matchup1 = {}
                    matchup1['id'] = f'{leagueID:0>3}-{week_number:0>2}-{day_number:0>2}-{match[0]:0>2}'
                    matchup1['team'] = match[0]
                    matchup1['matchup_id'] = str(matchup_id)
                    matchup1['day_number'] = str(day_number)
                    matchup1['leagueID'] = leagueID
                    matchup1['week_number'] = str(week_number)
                    matchup1['week_status'] = "initialized"
                    matchup1['day_status'] = "initialized"
                    matchup1['stocks'] = []
                    schedule_matchups.append(matchup1)

                    matchup2 = {}
                    matchup2['id'] = f'{leagueID:0>3}-{week_number:0>2}-{day_number:0>2}-{match[1]:0>2}'
                    matchup2['team'] = match[1]
                    matchup2['matchup_id'] = str(matchup_id)
                    matchup2['day_number'] = str(day_number)
                    matchup2['leagueID'] = leagueID
                    matchup2['week_number'] = str(week_number)
                    matchup2['week_status'] = "initialized"
                    matchup2['day_status'] = "initialized"
                    matchup2['stocks'] = []
                    schedule_matchups.append(matchup2)

            week_number = week_number + 1

        return schedule_matchups
        
    def createLeagueObject(self):
        league = {}
        league ['league'] = self.name
        league ['owner'] = self.owner
        league ['capacity'] = self.capacity
        league['start_date'] = self.startdate
        league['active_week'] = '0'
        league['active_day'] = '0'
        league ['teams'] = []
        

        #creating placeholders for teams
        for x in range(self.capacity):
            team = {}
            team ['teamID'] = str(x + 1)
            team ['team'] = ''
            team ['owner'] = ''
            team ['stocks'] = []
            league['teams'].append(team)

        return league
