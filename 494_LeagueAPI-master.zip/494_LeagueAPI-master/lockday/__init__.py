import logging
import json
import azure.functions as func
from shared_code.DataManager import FantasyStockDataStore


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueID = int(req_body.get('leagueID'))
        week_number = int(req_body.get('week_number'))
        day_number = int(req_body.get('day_number'))

        myDB = FantasyStockDataStore()
        matchups = myDB.GetWeekMatchups(leagueID, week_number)
        for matchup in matchups:
            if matchup['day_number'] == day_number:
                matchup['day_status'] = 'locked'
            if matchup['day_number'] == day_number + 1:
                matchup['day_status'] = 'ready'
            #TODO: Need to get stock price here....    
        myDB.UpdateWeekMatchups(matchups)
        result = {
            "active_day": f"{day_number}"
        }

        return func.HttpResponse(json.dumps(result, indent=True), status_code=200, headers={'Content-Type': 'application/json'})

    except Exception as e:
        return func.HttpResponse(
             f"UNEXPECTED ERROR - {e}", status_code=400)

