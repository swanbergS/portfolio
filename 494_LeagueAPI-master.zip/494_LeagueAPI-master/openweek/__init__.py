import logging
import json
import azure.functions as func
from shared_code.DataManager import FantasyStockDataStore


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP **OpenWeek** trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueID = int(req_body.get('leagueID'))
        week_number = int(req_body.get('week_number'))

        myDB = FantasyStockDataStore()
        matchups = myDB.GetWeekMatchups(leagueID, week_number)
        for matchup in matchups:
            matchup['week_status'] = 'open'
            if matchup['day_number'] == str(1):
                matchup['day_status'] = 'open'
        myDB.UpdateWeekMatchups(matchups)
        result = {
            "active_day": "1"
        }

        league = myDB.GetLeague(leagueID)
        league['active_week'] = f'{week_number}'
        league['active_day'] = '1'
        league = myDB.CreateOrUpdateLeague(league)

        return func.HttpResponse(json.dumps(league, indent=True), status_code=200, headers={'Content-Type': 'application/json'})

    except Exception as e:
        return func.HttpResponse(
             f"UNEXPECTED ERROR - {e}", status_code=400)

