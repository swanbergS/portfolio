from difflib import Match
import logging
import json
import azure.functions as func
from shared_code.DataManager import FantasyStockDataStore
from shared_code.MatchupBuilder import MatchupBuilder

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueID = int(req_body.get('leagueID'))
        week_number = int(req_body.get('week_number'))
        

        myDB = FantasyStockDataStore()
        matchups = myDB.GetWeekMatchups(leagueID, week_number, 1)

        if len(matchups) <= 0:
            return func.HttpResponse(f"Error: {leagueID}/{week_number} not found", status_code=400)

        matchupBuilder = MatchupBuilder(leagueID, week_number, matchups)
        matchResults = matchupBuilder.BuildOuput()

        return func.HttpResponse(json.dumps(matchResults, indent=True), status_code=200, headers={'Content-Type': 'application/json'})

    except Exception as e:
        return func.HttpResponse(f"UNEXPECTED ERROR - {e}", status_code=400)

