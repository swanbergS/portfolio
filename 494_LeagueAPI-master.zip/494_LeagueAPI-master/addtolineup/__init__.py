import logging
import json
import azure.functions as func
from shared_code.DataManager import FantasyStockDataStore


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueID = int(req_body.get("leagueID"))
        week_number = int(req_body.get('week_number'))
        team = int(req_body.get("team"))
        day_number = int(req_body.get('day_number'))
        stocks = req_body.get('stocks')

        myDB = FantasyStockDataStore()
        matchups = myDB.GetWeekLineup(leagueID,week_number,team)
        if (len(matchups) > 0):
            if matchups[0]['week_status'] != 'open':
                return func.HttpResponse(f'ERROR: Week={week_number} is NOT open for trading, leagueID={leagueID}', status_code=400, headers={'Content-Type': 'text/plain; charset=UTF-8'})

            for matchup in matchups:
                if matchup['day_status'] == 'ready':
                    for stock in stocks:
                        for current_stock in matchups['stocks']:
                            if stock['ticker'] == current_stock['ticker']:
                                current_stock['quantity'] = stock['quantity']
                myDB.UpdateWeekMatchups(matchups)

            return func.HttpResponse(json.dumps(matchups, indent=True), status_code=200, headers={'Content-Type': 'application/json'})
        else:
            return func.HttpResponse(f'ERROR: leagueID={leagueID}, week_number={week_number}, team={team} NOT FOUND', status_code=400, headers={'Content-Type': 'text/plain; charset=UTF-8'})
    except Exception as e:
        return func.HttpResponse(f"UNEXPECTED ERROR - {e}", status_code=400)