import logging
import json
import azure.functions as func
from azure.cosmos import CosmosClient

 

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP **GetMessageByID** trigger function processed a request.')

    id = req.params.get('id')

    #setup configuration for DB
    url = 'https://csc494.documents.azure.com:443/'
    key = 'a52fEosQTZjIV83PoHoRsVItHQ2tyd5tnFPlV7JWvPjwHsnRZF5EbiddN2zL7BNUamlftlGcQes9jn6vaZ656w=='
    database_name = 'csc494'
    container_name = 'Leagues'
    data_query = f'SELECT * FROM Leagues r WHERE r.id="{id}"'

    #query Database
    client = CosmosClient(url, credential=key)
    database = client.get_database_client(database_name)
    container = database.get_container_client(container_name)
    items = list(container.query_items(query=data_query, enable_cross_partition_query=True))
 
    if len(items) > 0:

       return func.HttpResponse(json.dumps(items[0], indent=True), status_code=200)

    else:

       return func.HttpResponse(f"{id} not found", status_code=404)