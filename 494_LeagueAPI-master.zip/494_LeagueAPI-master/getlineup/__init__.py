import logging
import json
import azure.functions as func
from shared_code.DataManager import FantasyStockDataStore


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
        leagueID = int(req_body.get("leagueID"))
        week_number = int(req_body.get('week_number'))
        team = int(req_body.get("team"))

        myDB = FantasyStockDataStore()
        matchups = myDB.GetWeekLineup(leagueID,week_number,team)
        if (len(matchups) > 0):
            stocks = matchups[0]['stocks']
            return func.HttpResponse(json.dumps(stocks, indent=True), status_code=200, headers={'Content-Type': 'application/json'})
        else:
            return func.HttpResponse(f'ERROR: leagueID={leagueID}, week_number={week_number}, team={team} NOT FOUND', status_code=400, headers={'Content-Type': 'text/plain; charset=UTF-8'})
    except Exception as e:
        return func.HttpResponse(f"UNEXPECTED ERROR - {e}", status_code=400)